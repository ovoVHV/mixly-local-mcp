'use strict';

const assert = require('node:assert');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const readline = require('node:readline');
const vm = require('node:vm');
const { spawn } = require('node:child_process');
const launcher = require('./launcher');
const installer = require('./install');

function listCompactTools() {
  const serverPath = path.join(__dirname, '..', 'mixly_mcp_server.js');
  const routerPath = path.join(__dirname, 'mcp_router.js');
  const mixlyHome = path.resolve(__dirname, '..', '..');
  const contextPath = path.join(__dirname, `.tmp-router-context-${process.pid}.json`);
  fs.writeFileSync(contextPath, `${JSON.stringify({
    mixlyHome,
    generation: '2',
    cdpPort: '',
    origin: ''
  })}\n`, 'utf8');
  const child = spawn(process.execPath, [routerPath], {
    cwd: path.join(__dirname, '..'),
    windowsHide: true,
    env: {
      ...process.env,
      MIXLY_CONTEXT_FILE: contextPath,
      MIXLY_MCP_NODE: process.execPath,
      MIXLY_MCP_SERVER: serverPath
    },
    stdio: ['pipe', 'pipe', 'inherit']
  });
  const lines = readline.createInterface({ input: child.stdout, crlfDelay: Infinity });
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error('Compact MCP tools/list timed out'));
    }, 10000);
    lines.on('line', (line) => {
      const message = JSON.parse(line);
      if (message.id === 1) {
        child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} })}\n`);
      } else if (message.id === 2) {
        clearTimeout(timer);
        child.stdin.end();
        fs.rmSync(contextPath, { force: true });
        resolve(message.result.tools.map((tool) => tool.name));
      }
    });
    child.on('error', (error) => {
      fs.rmSync(contextPath, { force: true });
      reject(error);
    });
    child.stdin.write(`${JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'harness-test', version: '1' } }
    })}\n`);
  });
}

async function main() {
  assert.deepEqual(launcher.parseArgs(['--mixly-home', 'C:\\Mixly', '--generation', '4']), {
    'mixly-home': 'C:\\Mixly',
    generation: '4'
  });
  assert.equal(launcher.instanceKey('C:\\Mixly'), launcher.instanceKey('c:\\mixly'));
  assert.equal(
    launcher.stableContextKey({ mixlyHome: 'C:\\Mixly', generation: '4', origin: 'http://localhost:65234', cdpPort: '9347' }),
    launcher.stableContextKey({ mixlyHome: 'c:\\mixly', generation: '4', origin: 'http://localhost:65234', cdpPort: '' }),
    'CDP port changes must not force a Harness restart for the same Mixly installation'
  );
  assert.notEqual(
    launcher.stableContextKey({ mixlyHome: 'C:\\Mixly', generation: '4', origin: 'http://localhost:65234' }),
    launcher.stableContextKey({ mixlyHome: 'C:\\Mixly', generation: '2', origin: '' }),
    'generation changes must still require a new Harness context'
  );
  const port = await launcher.choosePort();
  assert(port >= 3080 && port <= 3099);

  const rpcCalls = [];
  const rpcServer = http.createServer((request, response) => {
    const chunks = [];
    request.on('data', (chunk) => chunks.push(chunk));
    request.on('end', () => {
      const message = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      rpcCalls.push(message.method);
      let value;
      if (message.method === 'workspace.create') {
        value = { workspace: { workspaceId: 'workspace-1', path: 'C:\\Mixly' }, created: false };
      } else if (message.method === 'session.list') {
        value = { items: [{ sessionId: 'session-1', blank: true, cwd: 'c:\\mixly' }] };
      } else {
        response.writeHead(500).end();
        return;
      }
      response.writeHead(200, { 'content-type': 'application/json' });
      response.end(JSON.stringify({
        type: 'server-response',
        rpcId: message.rpcId,
        result: { ok: true, value }
      }));
    });
  });
  await new Promise((resolve) => rpcServer.listen(0, '127.0.0.1', resolve));
  try {
    const address = rpcServer.address();
    const workspace = await launcher.ensureHarnessWorkspace(`http://127.0.0.1:${address.port}`, 'C:\\Mixly', 2000);
    assert.deepEqual(workspace, {
      workspaceId: 'workspace-1',
      sessionId: 'session-1',
      createdSession: false
    });
    assert.deepEqual(rpcCalls, ['workspace.create', 'session.list']);
  } finally {
    await new Promise((resolve, reject) => rpcServer.close((error) => error ? reject(error) : resolve()));
  }

  const adapterSource = fs.readFileSync(path.join(__dirname, 'adapter', 'mixly_harness_adapter.js'), 'utf8');
  new vm.Script(adapterSource, { filename: 'mixly_harness_adapter.js' });
  assert(adapterSource.includes('mixly-harness-frame'));
  assert(adapterSource.includes('event.isTrusted'));
  assert(adapterSource.includes('Mixly AI · Mixly'));
  assert(adapterSource.includes('mixly-harness-panel-state-v1'));
  assert(adapterSource.includes('contextRefreshSkipped'));
  assert(adapterSource.includes('configuredMixlyHome || process.cwd()'));
  assert(adapterSource.includes("url.searchParams.set('mixlyLegacyCompat', '1')"));
  assert(adapterSource.includes("candidate('fs')"));
  assert(!adapterSource.includes('nw.Window.open'));
  assert(!adapterSource.includes("layui-btn-primary mixly-nav"));
  const mixly4Fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'mixly4-harness-global-'));
  try {
    fs.mkdirSync(path.join(mixly4Fixture, 'boards'), { recursive: true });
    fs.writeFileSync(path.join(mixly4Fixture, 'boards', 'index.html'), '<html><body></body></html>', 'utf8');
    const installed = installer.patchBoardsHtml(mixly4Fixture, 4);
    installer.patchBoardsHtml(mixly4Fixture, 4);
    const patchedHtml = fs.readFileSync(installed.htmlPath, 'utf8');
    assert(patchedHtml.includes('data-mixly-generation="4"'));
    assert(patchedHtml.includes(`data-mixly-home="${mixly4Fixture}"`));
    assert.equal((patchedHtml.match(/mixly-harness:start/g) || []).length, 1);
    assert(fs.existsSync(installed.adapterPath));
  } finally {
    fs.rmSync(mixly4Fixture, { recursive: true, force: true });
  }
  const runtimeFixture = fs.mkdtempSync(path.join(os.tmpdir(), 'mixly-harness-runtime-'));
  try {
    const frontend = path.join(
      runtimeFixture,
      'runtime',
      'dsh-app',
      'node_modules',
      '@deepseek-ai',
      'dsh-web-frontend',
      'dist'
    );
    fs.mkdirSync(frontend, { recursive: true });
    const indexPath = path.join(frontend, 'index.html');
    fs.writeFileSync(indexPath, '<!doctype html><html><head></head><body></body></html>', 'utf8');
    assert.equal(installer.installLegacyBrowserCompat(runtimeFixture), true);
    assert.equal(installer.installLegacyBrowserCompat(runtimeFixture), true);
    const patchedRuntime = fs.readFileSync(indexPath, 'utf8');
    assert(patchedRuntime.includes('AbortSignal.timeout'));
    assert(patchedRuntime.includes('AbortSignal.any'));
    assert.equal((patchedRuntime.match(/mixly-legacy-browser-compat:start/g) || []).length, 1);
  } finally {
    fs.rmSync(runtimeFixture, { recursive: true, force: true });
  }
  const pluginSource = fs.readFileSync(path.join(__dirname, 'mixly4_plugin', 'index.js'), 'utf8');
  assert(pluginSource.includes("export { blocks, generators }"));
  assert(pluginSource.includes('mixly_harness_adapter.js'));

  const patch = fs.readFileSync(path.join(__dirname, 'config', 'mixly-mcp.cordis.yml'), 'utf8');
  assert(patch.includes("name: '@deepseek-ai/dsh-mcp-client'"));
  assert(patch.includes('MIXLY_MCP_ROUTER'));
  const installerSource = fs.readFileSync(path.join(__dirname, '..', 'Install_Mixly4_AI.cmd'), 'utf8');
  assert(installerSource.includes('harness_integration\\install.js'));
  assert(installerSource.includes('--mixly4-home'));
  assert(installerSource.includes('process.versions.node'));
  assert(installerSource.includes('MixlyHarness\\runtime\\node\\node.exe'));
  const legacyInstallerSource = fs.readFileSync(path.join(__dirname, '..', 'Install_Mixly23_AI.cmd'), 'utf8');
  assert(legacyInstallerSource.includes('--mixly2-home'));
  assert(legacyInstallerSource.includes('--mixly3-home'));
  assert(legacyInstallerSource.includes('process.versions.node'));
  assert(legacyInstallerSource.includes('No Mixly 2 or Mixly 3 path was selected'));
  const installerRuntimeSource = fs.readFileSync(path.join(__dirname, 'install.js'), 'utf8');
  assert(installerRuntimeSource.includes("content-length"));
  assert(installerRuntimeSource.includes('runStreaming'));
  assert(installerRuntimeSource.includes("--progress=false"));
  assert(installerRuntimeSource.includes('npmmirror.com/mirrors/node'));
  assert(installerRuntimeSource.includes('MIXLY_NPM_REGISTRY'));
  assert(installerRuntimeSource.includes('--fetch-timeout=20000'));
  assert(!installerRuntimeSource.includes('--legacy-peer-deps'));
  assert(installerRuntimeSource.includes('cordis-plugin-group'));
  assert(installerRuntimeSource.includes('dsh-package-lock.json'));
  assert(installerRuntimeSource.includes('idleTimeoutMs: 180000'));
  assert(installerRuntimeSource.includes('replace-registry-host=always'));
  const tools = await listCompactTools();
  assert.equal(tools.length, 9);
  assert(tools.includes('mixly_build_project'));
  assert(tools.includes('mixly_project_workflow'));
  assert(!tools.includes('mixly_compile'));
  process.stdout.write('Harness integration static tests passed.\n');
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
